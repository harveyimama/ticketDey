package routosms;

import javax.xml.bind.DatatypeConverter;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.URL;
import java.net.URLEncoder;

public class RoutoTelecomSMS {

    public String user;
    public String pass;
    public String number;
    public String ownnum;
    public String message;
    public String messageId;
    public String type;
    public String model;
    public String op;

    public RoutoTelecomSMS() {
        this.user = "";
        this.pass = "";
        this.number = "";
        this.ownnum = "";
        this.message = "";
        this.messageId = "";
        this.type = "";
        this.model = "";
        this.op = "";
    }

    public String SetUser(String paramString) {
        this.user = paramString;
        return this.user;
    }

    public String SetPass(String paramString) {
        this.pass = paramString;
        return this.pass;
    }

    public String SetNumber(String paramString) {
        this.number = paramString;
        return this.number;
    }

    public String SetOwnNumber(String paramString) {
        this.ownnum = paramString;
        return this.ownnum;
    }

    public String SetType(String paramString) {
        this.type = paramString;
        return this.type;
    }

    public String SetModel(String paramString) {
        this.model = paramString;
        return this.model;
    }

    public String SetMessage(String paramString) {
        this.message = paramString;
        return this.message;
    }

    public String SetMessageId(String paramString) {
        this.messageId = paramString;
        return this.messageId;
    }

    public String SetOp(String paramString) {
        this.op = paramString;
        return this.op;
    }

    public String MIMEEncode(byte[] paramArrayOfByte) {    
        return DatatypeConverter.printBase64Binary(paramArrayOfByte);
    }

    public byte[] convertStringToByteArray(String paramString) {
        byte[] arrayOfByte = paramString.getBytes();
        return arrayOfByte;
    }

    public String getImage(String paramString) {
        String base64 = "";
        String line;
        String lines = "";
        byte[] arrayOfByte;
        
        try {
            URL localURL = new URL(paramString);
            BufferedReader localBufferedReader = new BufferedReader(new InputStreamReader(localURL.openStream()));

            while ((line = localBufferedReader.readLine()) != null) {
                lines += line;
            }
            
            localBufferedReader.close();
            arrayOfByte = convertStringToByteArray(lines);

            base64 = MIMEEncode(arrayOfByte);
        } catch (Exception localException) {
            System.err.println("Couldn't get I/O for the connection to server. " + localException.getMessage());
        }

        return base64;
    }

    public String urlencode(String paramString) {
        String encodedStr = "";
        
        try {
            encodedStr = URLEncoder.encode(paramString, "UTF-8");
        } catch(UnsupportedEncodingException e) {            
            System.err.println("UTF-8 is not supported. " + e.getMessage());
        }
        
        return encodedStr;        
    }

    public String Send() {        
        Socket localSocket;
        PrintWriter localPrintWriter;
        BufferedReader localBufferedReader;
        String params, headers, line;
        String response= "";        
        String host = "smsc5.routotelecom.com";
        int paramsStringLen;
        
        params = "number=" + this.number;
        params += "&user=" + urlencode(this.user);
        params += "&pass=" + urlencode(this.pass);
        params += "&message=" + urlencode(this.message);

        if (this.messageId.length() >= 1) {
            params += "&mess_id=" + urlencode(this.messageId) + "&delivery=1";
        }

        if (!this.ownnum.isEmpty()) {
            params += "&ownnum=" + urlencode(this.ownnum);
        }

        if (!this.model.isEmpty()) {
            params += "&model=" + urlencode(this.model);
        }

        if (!this.op.isEmpty()) {
            params += "&op=" + urlencode(this.op);
        }

        if (!this.type.isEmpty()) {
            params += "&type=" + urlencode(this.type);
        }

        paramsStringLen = params.length();
        
        headers = "POST /cgi-bin/SMSsend HTTP/1.0\nHost: " + host + "\n" + "Content-Type: application/x-www-form-urlencoded\n" + "Content-Length: " + paramsStringLen + "\n\n" + params + "\n";
       
        try {
            localSocket = new Socket(host, 80);

            localPrintWriter = new PrintWriter(localSocket.getOutputStream(), true);

            localBufferedReader = new BufferedReader(new InputStreamReader(localSocket.getInputStream()));

            localPrintWriter.println(headers);

            while((line = localBufferedReader.readLine()) != null) {
                response += " " + line;
            }
            
            //response = localBufferedReader.readLine();
            
        } catch (IOException localIOException) {
            System.err.println("Couldn't get I/O for the connection to server. " + localIOException.getMessage());
        }

        return headers + " " + response;
    }

    public String GetUser() {
        return this.user;
    }

    public String GetPass() {
        return this.pass;
    }

    public String GetNumber() {
        return this.number;
    }

    public String GetMessage() {
        return this.message;
    }

    public String GetMessageId() {
        return this.messageId;
    }

    public String GetOwnNum() {
        return this.ownnum;
    }

    public String GetOp() {
        return this.op;
    }

    public String GetType() {
        return this.type;
    }

    public String GetModel() {
        return this.model;
    }
}